#pragma once

#include "Math.hpp"

struct OrbitCamera
{
    Vec3 target{ 0.f, 0.f, 0.f };
    float distance = 6.0f;
    float yaw = 0.0f;   // radians
    float pitch = 0.4f; // radians

    float minDistance = 1.5f;
    float maxDistance = 25.0f;

    float rotateSpeed = 0.01f;
    float zoomSpeed = 0.5f;

    Mat4 GetViewMatrix() const;

    void OnMouseDrag(float dxPixels, float dyPixels);
    void OnScroll(float yOffset);
};

