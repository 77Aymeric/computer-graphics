#include "DragonMesh.hpp"

#include <cstddef>

#include <GL/glew.h>

#include "../../../DragonData.h"

#ifdef __APPLE__
#define GL_GEN_VERTEX_ARRAYS glGenVertexArraysAPPLE
#define GL_BIND_VERTEX_ARRAY glBindVertexArrayAPPLE
#define GL_DELETE_VERTEX_ARRAYS glDeleteVertexArraysAPPLE
#else
#define GL_GEN_VERTEX_ARRAYS glGenVertexArrays
#define GL_BIND_VERTEX_ARRAY glBindVertexArray
#define GL_DELETE_VERTEX_ARRAYS glDeleteVertexArrays
#endif

bool DragonMesh::Initialize(uint32_t program)
{
    // Trace TP02 (rendu 3D simple): mesh indexé + dragon (positions + normales + UV)
    // Layout: 8 floats per vertex: X Y Z  NX NY NZ  U V
    const int strideBytes = 8 * sizeof(float);

    const int locPos = glGetAttribLocation(program, "a_Position");
    const int locNormal = glGetAttribLocation(program, "a_Normal");

    if (locPos < 0 || locNormal < 0)
        return false;

    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(DragonVertices), DragonVertices, GL_STATIC_DRAW);

    glGenBuffers(1, &ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(DragonIndices), DragonIndices, GL_STATIC_DRAW);

    GL_GEN_VERTEX_ARRAYS(1, &vao);
    GL_BIND_VERTEX_ARRAY(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);

    glVertexAttribPointer(locPos, 3, GL_FLOAT, GL_FALSE, strideBytes, (void*)0);
    glEnableVertexAttribArray(locPos);

    glVertexAttribPointer(locNormal, 3, GL_FLOAT, GL_FALSE, strideBytes, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(locNormal);

    // Optional UV exists (offset 6 floats) but not used for the mandatory part.

    GL_BIND_VERTEX_ARRAY(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    indexCount = (int)(sizeof(DragonIndices) / sizeof(DragonIndices[0]));
    return true;
}

void DragonMesh::Destroy()
{
    if (vao) GL_DELETE_VERTEX_ARRAYS(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
    vao = vbo = ebo = 0;
    indexCount = 0;
}

void DragonMesh::Draw() const
{
    GL_BIND_VERTEX_ARRAY(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_SHORT, nullptr);
}

