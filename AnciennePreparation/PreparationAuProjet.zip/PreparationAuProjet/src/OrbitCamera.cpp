#include "OrbitCamera.hpp"

static float Clamp(float v, float a, float b)
{
    if (v < a) return a;
    if (v > b) return b;
    return v;
}

Mat4 OrbitCamera::GetViewMatrix() const
{
    // spherical coordinates around target
    float cp = std::cos(pitch);
    float sp = std::sin(pitch);
    float cy = std::cos(yaw);
    float sy = std::sin(yaw);

    Vec3 eyeOffset{
        distance * cp * sy,
        distance * sp,
        distance * cp * cy
    };

    Vec3 eye = target + eyeOffset;
    Vec3 up{ 0.f, 1.f, 0.f };
    return LookAt(eye, target, up);
}

void OrbitCamera::OnMouseDrag(float dxPixels, float dyPixels)
{
    yaw += dxPixels * rotateSpeed;
    pitch += dyPixels * rotateSpeed;

    // clamp pitch to avoid flipping (simple)
    pitch = Clamp(pitch, -1.5f, 1.5f);
}

void OrbitCamera::OnScroll(float yOffset)
{
    distance -= yOffset * zoomSpeed;
    distance = Clamp(distance, minDistance, maxDistance);
}

