#pragma once

#include <cstdint>

struct DragonMesh
{
    uint32_t vao = 0;
    uint32_t vbo = 0;
    uint32_t ebo = 0;
    int indexCount = 0;

    // Expects current OpenGL context.
    bool Initialize(uint32_t program);
    void Destroy();
    void Draw() const;
};

