#pragma once

#include <cmath>

struct Vec3
{
    float x = 0.f;
    float y = 0.f;
    float z = 0.f;
};

inline Vec3 operator+(const Vec3& a, const Vec3& b) { return { a.x + b.x, a.y + b.y, a.z + b.z }; }
inline Vec3 operator-(const Vec3& a, const Vec3& b) { return { a.x - b.x, a.y - b.y, a.z - b.z }; }
inline Vec3 operator*(const Vec3& v, float s) { return { v.x * s, v.y * s, v.z * s }; }

inline float Dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline Vec3 Cross(const Vec3& a, const Vec3& b)
{
    return {
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    };
}

inline float Length(const Vec3& v) { return std::sqrt(Dot(v, v)); }
inline Vec3 Normalize(const Vec3& v)
{
    float len = Length(v);
    if (len <= 1e-8f) return { 0.f, 0.f, 0.f };
    return v * (1.f / len);
}

// Column-major 4x4 matrix (OpenGL style)
struct Mat4
{
    float m[16] = {
        1,0,0,0,
        0,1,0,0,
        0,0,1,0,
        0,0,0,1
    };
};

inline Mat4 Identity()
{
    return Mat4{};
}

inline Mat4 RotationY(float radians)
{
    Mat4 r = Identity();
    float c = std::cos(radians);
    float s = std::sin(radians);

    // column-major
    r.m[0] = c;  r.m[4] = 0; r.m[8]  = -s; r.m[12] = 0;
    r.m[1] = 0;  r.m[5] = 1; r.m[9]  = 0;  r.m[13] = 0;
    r.m[2] = s;  r.m[6] = 0; r.m[10] = c;  r.m[14] = 0;
    r.m[3] = 0;  r.m[7] = 0; r.m[11] = 0;  r.m[15] = 1;
    return r;
}

inline Mat4 Translation(const Vec3& t)
{
    Mat4 m = Identity();
    m.m[12] = t.x;
    m.m[13] = t.y;
    m.m[14] = t.z;
    return m;
}

inline Mat4 Mul(const Mat4& A, const Mat4& B)
{
    Mat4 R{};
    for (int c = 0; c < 4; ++c)
    {
        for (int r = 0; r < 4; ++r)
        {
            R.m[c * 4 + r] =
                A.m[0 * 4 + r] * B.m[c * 4 + 0] +
                A.m[1 * 4 + r] * B.m[c * 4 + 1] +
                A.m[2 * 4 + r] * B.m[c * 4 + 2] +
                A.m[3 * 4 + r] * B.m[c * 4 + 3];
        }
    }
    return R;
}

inline Mat4 Perspective(float fovyRadians, float aspect, float zNear, float zFar)
{
    float f = 1.f / std::tan(fovyRadians * 0.5f);
    Mat4 p{};
    for (int i = 0; i < 16; ++i) p.m[i] = 0.f;

    p.m[0] = f / aspect;
    p.m[5] = f;
    p.m[10] = (zFar + zNear) / (zNear - zFar);
    p.m[11] = -1.f;
    p.m[14] = (2.f * zFar * zNear) / (zNear - zFar);
    return p;
}

// Right-handed LookAt (like gluLookAt): returns VIEW matrix (world -> camera)
inline Mat4 LookAt(const Vec3& eye, const Vec3& target, const Vec3& up)
{
    Vec3 f = Normalize(target - eye);
    Vec3 s = Normalize(Cross(f, up));
    Vec3 u = Cross(s, f);

    Mat4 m = Identity();

    // Column-major: basis vectors in columns
    m.m[0] = s.x; m.m[4] = s.y; m.m[8]  = s.z;
    m.m[1] = u.x; m.m[5] = u.y; m.m[9]  = u.z;
    m.m[2] = -f.x; m.m[6] = -f.y; m.m[10] = -f.z;

    // Translation
    m.m[12] = -Dot(s, eye);
    m.m[13] = -Dot(u, eye);
    m.m[14] = Dot(f, eye);

    return m;
}

struct Mat3
{
    float m[9] = { 1,0,0, 0,1,0, 0,0,1 };
};

inline Mat3 Mat3FromMat4(const Mat4& M)
{
    Mat3 r{};
    // upper-left 3x3, column-major
    r.m[0] = M.m[0]; r.m[1] = M.m[1]; r.m[2] = M.m[2];
    r.m[3] = M.m[4]; r.m[4] = M.m[5]; r.m[5] = M.m[6];
    r.m[6] = M.m[8]; r.m[7] = M.m[9]; r.m[8] = M.m[10];
    return r;
}

inline Mat3 Transpose(const Mat3& A)
{
    Mat3 T{};
    T.m[0] = A.m[0]; T.m[3] = A.m[1]; T.m[6] = A.m[2];
    T.m[1] = A.m[3]; T.m[4] = A.m[4]; T.m[7] = A.m[5];
    T.m[2] = A.m[6]; T.m[5] = A.m[7]; T.m[8] = A.m[8];
    return T;
}

inline float Det(const Mat3& A)
{
    return
        A.m[0] * (A.m[4] * A.m[8] - A.m[7] * A.m[5]) -
        A.m[3] * (A.m[1] * A.m[8] - A.m[7] * A.m[2]) +
        A.m[6] * (A.m[1] * A.m[5] - A.m[4] * A.m[2]);
}

inline Mat3 Inverse(const Mat3& A)
{
    Mat3 inv{};
    float det = Det(A);
    if (std::fabs(det) < 1e-8f)
        return inv; // identity fallback

    float id = 1.f / det;
    inv.m[0] =  (A.m[4] * A.m[8] - A.m[5] * A.m[7]) * id;
    inv.m[1] = -(A.m[1] * A.m[8] - A.m[2] * A.m[7]) * id;
    inv.m[2] =  (A.m[1] * A.m[5] - A.m[2] * A.m[4]) * id;

    inv.m[3] = -(A.m[3] * A.m[8] - A.m[5] * A.m[6]) * id;
    inv.m[4] =  (A.m[0] * A.m[8] - A.m[2] * A.m[6]) * id;
    inv.m[5] = -(A.m[0] * A.m[5] - A.m[2] * A.m[3]) * id;

    inv.m[6] =  (A.m[3] * A.m[7] - A.m[4] * A.m[6]) * id;
    inv.m[7] = -(A.m[0] * A.m[7] - A.m[1] * A.m[6]) * id;
    inv.m[8] =  (A.m[0] * A.m[4] - A.m[1] * A.m[3]) * id;

    return inv;
}

inline Mat3 NormalMatrixFromModel(const Mat4& model)
{
    Mat3 m3 = Mat3FromMat4(model);
    return Transpose(Inverse(m3));
}

