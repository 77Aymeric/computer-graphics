#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#include "../../common/GLShader.h"

#include "src/Math.hpp"
#include "src/OrbitCamera.hpp"
#include "src/DragonMesh.hpp"

static const int WINDOW_WIDTH = 960;
static const int WINDOW_HEIGHT = 540;

static bool g_LeftMouseDown = false;
static double g_LastMouseX = 0.0;
static double g_LastMouseY = 0.0;

static OrbitCamera g_Camera;

static void CursorPosCallback(GLFWwindow* window, double x, double y)
{
    (void)window;
    if (!g_LeftMouseDown)
    {
        g_LastMouseX = x;
        g_LastMouseY = y;
        return;
    }

    float dx = float(x - g_LastMouseX);
    float dy = float(y - g_LastMouseY);
    g_LastMouseX = x;
    g_LastMouseY = y;

    g_Camera.OnMouseDrag(dx, dy);
}

static void MouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    (void)window;
    (void)mods;
    if (button == GLFW_MOUSE_BUTTON_LEFT)
    {
        g_LeftMouseDown = (action == GLFW_PRESS);
    }
}

static void ScrollCallback(GLFWwindow* window, double xOffset, double yOffset)
{
    (void)window;
    (void)xOffset;
    g_Camera.OnScroll((float)yOffset);
}

static bool WritePPM(const char* filename, int w, int h, const unsigned char* rgb)
{
    FILE* f = std::fopen(filename, "wb");
    if (!f) return false;

    std::fprintf(f, "P6\n%d %d\n255\n", w, h);
    std::fwrite(rgb, 1, (size_t)(w * h * 3), f);
    std::fclose(f);
    return true;
}

static bool SaveScreenshotPPM(const std::string& filenameNoExt, int w, int h)
{
    // Read back framebuffer as RGB
    unsigned char* pixels = (unsigned char*)std::malloc((size_t)w * (size_t)h * 3);
    if (!pixels) return false;

    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, pixels);

    // Flip vertically (OpenGL origin is bottom-left)
    unsigned char* flipped = (unsigned char*)std::malloc((size_t)w * (size_t)h * 3);
    if (!flipped) { std::free(pixels); return false; }

    for (int y = 0; y < h; ++y)
    {
        std::memcpy(flipped + (size_t)y * (size_t)w * 3,
                    pixels + (size_t)(h - 1 - y) * (size_t)w * 3,
                    (size_t)w * 3);
    }

    std::string ppmPath = filenameNoExt + ".ppm";
    bool ok = WritePPM(ppmPath.c_str(), w, h, flipped);

    std::free(pixels);
    std::free(flipped);
    return ok;
}

int main()
{
    // Trace TP/TD:
    // - TD OpenGL moderne 4A partie 01: pipeline + VBO/IBO/VAO + attributs
    // - TP OpenGL moderne 02: rendu 3D (projection perspective + depth test + culling)
    // - TP Transformations: matrices M/V/P envoyées en uniforms
    // - TP illumination (partie 01): éclairage minimal diffuse + ambient pour valider les normales
    // - Devoir préparation projet: caméra orbitale + LookAt + normal matrix

    if (!glfwInit())
        return -1;

    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Preparation au projet - Dragon", nullptr, nullptr);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetCursorPosCallback(window, CursorPosCallback);
    glfwSetMouseButtonCallback(window, MouseButtonCallback);
    glfwSetScrollCallback(window, ScrollCallback);

    GLenum err = glewInit();
    if (err != GLEW_OK)
    {
        std::printf("Erreur GLEW\n");
    }

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    GLShader shader;
    shader.LoadVertexShader("shaders/project.vs.glsl");
    shader.LoadFragmentShader("shaders/project.fs.glsl");
    if (!shader.Create())
    {
        std::printf("Erreur: shader program\n");
        return -1;
    }

    uint32_t program = shader.GetProgram();
    glUseProgram(program);

    DragonMesh dragon;
    if (!dragon.Initialize(program))
    {
        std::printf("Erreur: init dragon mesh (attribs)\n");
        return -1;
    }

    // Uniform locations
    int locModel = glGetUniformLocation(program, "u_Model");
    int locView = glGetUniformLocation(program, "u_View");
    int locProj = glGetUniformLocation(program, "u_Projection");
    int locNormalMat = glGetUniformLocation(program, "u_NormalMatrix");
    int locLightDir = glGetUniformLocation(program, "u_LightDir");
    int locBaseColor = glGetUniformLocation(program, "u_BaseColor");

    // Camera defaults (simple)
    g_Camera.target = { 0.f, 1.0f, 0.f };
    g_Camera.distance = 8.0f;
    g_Camera.yaw = 0.2f;
    g_Camera.pitch = 0.3f;

    const bool autoCapture = (std::getenv("AUTO_CAPTURE") != nullptr);
    bool capturedOverview = false;
    bool capturedOrbitLeft = false;
    bool capturedOrbitRight = false;
    bool capturedZoom = false;

    while (!glfwWindowShouldClose(window))
    {
        int w = 0, h = 0;
        glfwGetFramebufferSize(window, &w, &h);
        glViewport(0, 0, w, h);

        glClearColor(0.12f, 0.12f, 0.14f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // TP Transformations: M / V / P
        float aspect = (h > 0) ? (float(w) / float(h)) : 1.f;
        Mat4 projection = Perspective(60.f * 3.1415926f / 180.f, aspect, 0.1f, 100.f);
        Mat4 view = g_Camera.GetViewMatrix();

        // Simple slow rotation to show 3D
        float t = (float)glfwGetTime();
        Mat4 model = RotationY(t * 0.3f);

        // Devoir: normal matrix dédiée (dépend de M seulement, pas de V)
        Mat3 normalMat = NormalMatrixFromModel(model);

        glUseProgram(program);
        glUniformMatrix4fv(locModel, 1, GL_FALSE, model.m);
        glUniformMatrix4fv(locView, 1, GL_FALSE, view.m);
        glUniformMatrix4fv(locProj, 1, GL_FALSE, projection.m);
        glUniformMatrix3fv(locNormalMat, 1, GL_FALSE, normalMat.m);

        if (locLightDir >= 0) glUniform3f(locLightDir, 0.2f, 0.9f, 0.4f);
        if (locBaseColor >= 0) glUniform3f(locBaseColor, 0.85f, 0.65f, 0.45f);

        dragon.Draw();

        // Manual screenshot on key press P
        if (!autoCapture && glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
            SaveScreenshotPPM("screens/capture", w, h);

        // Auto screenshots (for report): generates the 4 required views and exits.
        if (autoCapture)
        {
            if (!capturedOverview)
            {
                SaveScreenshotPPM("screens/01_overview", w, h);
                capturedOverview = true;
            }
            else if (!capturedOrbitLeft)
            {
                g_Camera.yaw -= 0.8f;
                SaveScreenshotPPM("screens/02_orbit_left", w, h);
                capturedOrbitLeft = true;
            }
            else if (!capturedOrbitRight)
            {
                g_Camera.yaw += 1.6f;
                SaveScreenshotPPM("screens/03_orbit_right", w, h);
                capturedOrbitRight = true;
            }
            else if (!capturedZoom)
            {
                g_Camera.distance = 4.0f;
                SaveScreenshotPPM("screens/04_zoom", w, h);
                capturedZoom = true;
                glfwSetWindowShouldClose(window, GLFW_TRUE);
            }
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    dragon.Destroy();
    shader.Destroy();

    glfwTerminate();
    return 0;
}

